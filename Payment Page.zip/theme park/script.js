const numberAdult = document.getElementById('numberAdult');
let adultCount = parseInt(numberAdult.value);
numberAdult.addEventListener('change',()=>{
    adultCount = numberAdult.value * 69;
    console.log(adultCount);
});

const numberChildren = document.getElementById("numberChildren")
let childrenCount = parseInt(numberChildren.value);
numberChildren.addEventListener("change", () => {
    childrenCount = numberChildren.value * 59;
    console.log(childrenCount);
});

const numberElderly = document.getElementById("numberElderly")
let elderlyCount = parseInt(numberElderly.value);
numberElderly.addEventListener("change", () => {
    elderlyCount = numberElderly.value * 49;
    console.log(elderlyCount);
});

 
const sum = 0
sum.addEventListener('change' , () => {
    sum = adultCount + childrenCount + elderlyCount;
    document.getElementById('getPrice').innerHTML = sum;
});